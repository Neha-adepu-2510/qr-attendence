from django.apps import AppConfig


class AttendanceappConfig(AppConfig):
    name = 'AttendanceApp'
